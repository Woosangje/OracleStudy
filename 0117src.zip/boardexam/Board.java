package boardexam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Board {
	// 필드
	public Scanner in = new Scanner(System.in); //같은 패키지에서 스캐너 객체 공용 활용
	private static BoardDAO bdao = new BoardDAO(); //crud용 객체 생성(단일 객체로 생성)
	public Connection conn= null; // 1단계
	// 생성자
	public Board() {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection
					("jdbc:oracle:thin:@192.168.0.203:1521:xe", "boardtest", "boardtest" );
			//2단계
			System.out.println("jdbc연결 성공");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("jdbc드라이버나, url, id, pw 문제 발생");
			System.out.println("Board 생성자를 확인하세요.");
			e.printStackTrace();
			System.exit(0); // 강제 종료
		}
		
	}
	
	// 메서드
	
	public static void main(String[] args) throws SQLException {
		// jdbc를 이용하여 dto , dao를 활용한다.
		Board board = new Board(); // 자신객체 실행시 자동으로 1단게, 2단계 셋팅
		board.list(); //리스트메서드 호출
		

	}

	public void list() throws SQLException { //리스트 메서드 동작
		// 게시물의 목록을 보여준다.
		System.out.println();
		System.out.println("[게시물 목록]");
		System.out.println("---------------------------------------------------------");
		System.out.printf("%-6s %-17s %-18s %-40s \n", "no", "writer", "date", "title");
		System.out.println("---------------------------------------------------------");
		
		//db에 있는 내용을 모두 가져와 출력
		try {
			String sql = "select bno, btitle, bcontent, bwriter, bdate from board order by bno desc";
			// board 테이블에 있는 모든 것을 bno 내림차순하여 가져오기
			PreparedStatement pstmt = conn.prepareStatement(sql); //쿼리문 생성 및 입력 (3단계)
			ResultSet rs = pstmt.executeQuery(); //쿼리문 실행 결과를 표형식(ResultSet)으로 받음(4단계)
			
			while(rs.next()) { //ResultSet에 있는 표 행 반복용 1행~ 끝까지(false)
				BoardDTO dbto = new BoardDTO(); // dto 객체 생성
				dbto.setBno(rs.getInt("bno"));	// ResultSet에 있는 bno값을 bto에 넣는다.
				dbto.setBtitle(rs.getString("btitle"));
				dbto.setBcontent(rs.getString("bcontent"));
				dbto.setBwriter(rs.getString("bwriter"));
				dbto.setBdate(rs.getDate("bdate")); // BoardDTO객체 완성
				System.out.printf("%-6s %-12s %-16s %-40s \n", dbto.getBno(), //BoardDTO에 있는 필드값을 순서대로 출력
						dbto.getBwriter(), dbto.getBdate(), dbto.getBtitle());
				
				
			}
			//5단계
			rs.close();
			pstmt.close();
			
		} catch (SQLException e) {
			System.out.println("list()메서드 예외발생, 쿼리문이나 pstmt 부분을 확인하세요.");
			e.printStackTrace();
		}finally {
			mainMenu();
		}
		
	}

	public void mainMenu() throws SQLException{
		// 게시물의 crud를 담당 -> dao를 활용한다.(sql문)
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println("메인 메뉴 : 1. Create | 2. Read | 3. Clear | 4.Exit");
		System.out.println("메뉴 선택 : ");
		int menuNo = in.nextInt(); //메뉴 입력
		System.out.println();
		
		switch(menuNo) {
		case 1 :
			bdao.create();
			break;
		case 2 :
			bdao.read();
			break;
		case 3 :
			bdao.clear();
			break;
		case 4 :
			bdao.exit();
			break;
		default :
			System.out.println("1~4값만 넣으세요.");
			
		}//스위치 문 종료
	}

}
