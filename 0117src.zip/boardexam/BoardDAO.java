package boardexam;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BoardDAO { // BoardDTO를 db와 curd 할 수 있도록 객체화
	// 필드
	Board board = new Board(); // 1단계, 2단계 jdbc 실행
	// 생성자

	// 메서드
	public void create() throws SQLException { // 새로운 게시물 등록 할 수 있다.
		BoardDTO bdto = new BoardDTO();
		System.out.println("[새 게시물 입력]");

		System.out.print("제목 : ");
		bdto.setBtitle(board.in.next()); // Board에 있는 스케너 활용

		board.in.nextLine(); // 띠어쓰기 오류 해결용
		System.out.print("내용 : ");
		bdto.setBcontent(board.in.nextLine()); // Board에 있는 스케너 활용

		System.out.print("작성자 : ");
		bdto.setBwriter(board.in.next()); // Board에 있는 스케너 활용

		// 보조 메뉴
		System.out.println("---------------------------------");
		System.out.println("보조 메뉴 : 1.OK | 2.Cancel ");
		System.out.print("메뉴 선택 : ");
		int subMenuNo = board.in.nextInt(); // 메뉴값을 정수로 받아 1이면 insert, 2면 저장 안함
		board.in.nextLine();
		if (subMenuNo == 1) {

			try {
				String sql = "insert into board(bno, btitle, bcontent, bwriter, bdate)"
						+ "values(board_seq.nextval, ?, ?, ?, sysdate)";
				PreparedStatement pstmt = board.conn.prepareStatement(sql);
				pstmt.setString(1, bdto.getBtitle());
				pstmt.setString(2, bdto.getBcontent());
				pstmt.setString(3, bdto.getBwriter()); // sql문 완성
				int n = pstmt.executeUpdate();

				if (n > 0) {
					System.out.println(n + "개의 게시물이 등록 되어 있습니다.");
					board.conn.commit();
				}

				pstmt.close();
			} catch (SQLException e) {
				System.out.println("insert문 예외발생 : dao.create()메서드 확인하세요");
				e.printStackTrace();
				board.conn.rollback();
				exit();	//예외발생시 db연결 종료
			} // 예외처리 종료

		} // 1.ok if문 종료

		board.list(); // 게시물 목록 보기 실행
	} // create() 종료

	public void read() throws SQLException {
		// 게시물에 있는 번호를 선택하여 내용을 보여 준다.
		System.out.println("[게시물 내용 보기]");
		System.out.print("bno : ");
		int bno = board.in.nextInt(); // 키보드로 입력
		board.in.nextLine(); // 한줄 처리용

		try {
			String sql = "select bno, btitle, bcontent, bwriter, bdate from board where bno = ? ";
			PreparedStatement pstmt = board.conn.prepareStatement(sql);
			pstmt.setInt(1, bno);

			ResultSet rs = pstmt.executeQuery(); // 쿼리 실행후 테이블형식으로 받음
			
			if(rs.next()) {
				BoardDTO bdto = new BoardDTO(); 
				bdto.setBno(rs.getInt("bno"));
				bdto.setBtitle(rs.getString("btitle"));
				bdto.setBcontent(rs.getString("bcontent"));
				bdto.setBwriter(rs.getString("bwriter"));
				bdto.setBdate(rs.getDate("bdate")); //rs값에 있는 내용을 dto 객체에 넣음
				System.out.println("#####################");
				System.out.println("번호 : " + bdto.getBno() );
				System.out.println("제목 : " + bdto.getBtitle() );
				System.out.println("내용 : " + bdto.getBcontent() );
				System.out.println("작성자 : " + bdto.getBwriter() );
				System.out.println("작성일 : " + bdto.getBdate() );
				System.out.println("#####################");
				
				//보조 메뉴 
				System.out.println("----------------------");
				System.out.println("보조메뉴 : 1. Update | 2. Delete | 3. List ");
				System.out.print("메뉴 선택 : ");
				int subMenuNo = board.in.nextInt();
				board.in.nextLine();
				if (subMenuNo == 1) {
					update(bdto); // 데이터 수정용 메서드 호출(dto 객체 전달)
				}else if (subMenuNo == 2) {
					delete(bdto); // 데이터 삭제용 메서드 호출(dto 객체 전달)
				}else {
					board.list(); // 3번이나 다른 키를 눌렀을 때 리스트로 돌아감
				}
		
			}else {
				System.out.println("해당하는 게시물이 존재하지 않습니다.");
			}//if문 종료
						
		} catch (SQLException e) {
			System.out.println("select문 예외발생 : dao.read()메서드 확인하세요");
			e.printStackTrace();
			exit();	//예외발생시 db연결 종료
		}//예외처리 종료
		
		board.list();  

	} //read() 메서드종료

	private void delete(BoardDTO bdto) throws SQLException { // 매개값이 번호를 이용하여 색출한 객체( bno 번호를 이용하여 제거)
		// 게시물을 보다가 게시물을 삭제하고 싶을 때
		try{
			PreparedStatement pstmt = board.conn.prepareStatement("delete from board where bno = ? ");
			pstmt.setInt(1, bdto.getBno());
			int n = pstmt.executeUpdate();
			if(n > 0) {
				System.out.println(n + "게시물이 삭제 되었습니다.");
				board.conn.commit();
			}else {
				System.out.println("게시물이 삭제되지 않았습니다.");
				board.conn.rollback();
			}
		} catch(SQLException e) {
			e.printStackTrace();
			exit();
		} //예외처리 종료
		board.list();
	}//delete() 메서드 종료
	

	public void update(BoardDTO bdto) { // 매개값이 번호를 이용하여 색출한 객체
		// 게시물을 보다가 그 내용을 수정한다.
		// 수정할 내용 입력
			System.out.println("[수정할 내용 입력]");
			System.out.println("제목 : ");
			bdto.setBtitle(board.in.nextLine());
			
			System.out.println("내용 : ");
			bdto.setBcontent(board.in.nextLine());
			
			System.out.println("작성자 : ");
			bdto.setBwriter(board.in.nextLine());
			
			//보조 메뉴
			System.out.println("-------------------------------------");
			System.out.println("보조 메뉴 : 1.OK | 2.Cancel ");
			System.out.println("메뉴 선택 : ");
			int ssubMenuNo = board.in.nextInt();
			
			if(ssubMenuNo == 1) {	//수정 작업
				try {
					String sql = "update board set btitle = ? ,  bcontent = ? ,  bwriter = ? where bno = ?";
					PreparedStatement pstmt = board.conn.prepareStatement(sql);
					pstmt.setString(1,  bdto.getBtitle());
					pstmt.setString(2,  bdto.getBcontent());
					pstmt.setString(3,  bdto.getBwriter());
					pstmt.setInt(4, bdto.getBno()); // sql문 완성
					
					int n = pstmt.executeUpdate(); // 실행후 결과를 int로 보냄
					if(n > 0) {
						System.out.println(n + "개의 데이터가 수정 되었습니다. ");
						board.conn.commit();
					}else {
						System.out.println("수정이 되지 않았습니다.");
					}
					
					pstmt.close();
				}catch(SQLException e) {
					e.printStackTrace();
					exit();	//예외발생시 db연결 종료
				} // 예외문 종료
			
			}//if문 종료
	} // update() 종료

	public void exit() {
		// 예외발생시 db연결 등을 종료하는 명령어
		System.out.println("프로그램 종료");
		if(board.conn !=null) {
			
			try {
				board.conn.close();
			}catch(SQLException e) {
				System.out.println("exit()메서드 오류 : BoardDAO.exit() 메서드 확인 요망");
				e.printStackTrace();
			}
		}// if문 종료
		System.out.println("** 게시판이 정상적으로 종료 되었습니다. **");
		System.exit(0); //프로그램 강제 종료
	} //exit() 메서드 종료

	public void clear() throws SQLException {
		// 관리자용 전체삭제
		System.out.println("[전체 자료 삭제]");
		System.out.println("-----------------------");
		System.out.println("보조 메뉴 : 1.Ok | 2.Cancel");
		System.out.println("메뉴 선택 : ");
		String subMenuNo = board.in.nextLine();
		if(subMenuNo.equals("1")) { //전체 삭제 진행
			try {
				PreparedStatement pstmt = board.conn.prepareStatement("truncate table board");
				//테이블에 있는 모든 자료를 삭제한다. (관리자용으로 주의할 것)
				pstmt.executeUpdate();
				pstmt.close();
				System.out.println("모든 자료가 지워졌습니다.");
				board.conn.commit();
			} catch(SQLException e) {
				e.printStackTrace();
				exit();
			}//예외처리 종료
		}else {
			System.out.println("삭제가 진행되지 않았습니다.");
		}
		board.list();
	} //clear() 메서드 종료

} //BoardDAO 클래스 종료
