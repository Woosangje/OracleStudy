package jdbcProject;

import java.sql.SQLException;
import java.util.Scanner;

public class Main1Exam {
	static Scanner in = new Scanner(System.in);
	static JDBCTest jt = new JDBCTest(); // 객체 생성

	public static void main(String[] args) throws Exception {
		// jdbc 테스트용 실행 코드

		boolean run = true; // 실행용 코드

		while (run) {
			System.out.println("--------------------------------");
			System.out.println("----emp 테이블에 오신 것을 황영합니다.---");
			System.out.println("1. 전체보기 | 2. 입력(stmt) | 3. 입력(pstmt) | 4. 수정 | 5. 삭제 ");
			System.out.println(">>>");
			int select = in.nextInt();
			switch (select) {
			case 1:
				jt.selectEmp(); // 전체 정보 보기
				break;
			case 2:
				System.out.println("이름을 입력하세요");
				System.out.println(">>>");
				String name = in.next();
				System.out.println("부서를 입력하세요");
				System.out.println(">>>");
				String dept = in.next();
				System.out.println("입사점수를 입력하세요(소수점2까지)");
				double score = in.nextDouble();
				jt.insertEmp1(name, dept, score);

				break;
			case 3:
				System.out.println("이름을 입력하세요");
				System.out.println(">>>");
				String pname = in.next();
				System.out.println("부서를 입력하세요");
				System.out.println(">>>");
				String pdept = in.next();
				System.out.println("입사점수를 입력하세요(소수점2까지)");
				double pscore = in.nextDouble();
				jt.insertEmp2(pname, pdept, pscore);
				break;
			case 4:
				printModify();
				break;
			case 5:
				break;

			default:
				System.out.println("1~5까지만 입력 바랍니다.");
				break;
			}

		}
		jt.selectEmp(); // 전체 정보 보기

	}

	private static void printModify() {
		// 수정
		System.out.println("---- 정보 수정 ----");
		System.out.println("     검색 방법     ");
		System.out.println("1.이룸 ,     2.번호");
		int select = in.nextInt();
		switch (select) {
		case 1:
			System.out.println("이름 입력: ");
			System.out.println(">>>");
			String name = in.next();
			// 이름으로 검색하는 메소드
			try {
				if (jt.isFindEmp(name) == true) {
				System.out.println("새로운 이름:");
				System.out.println(">>>");
				String newName = in.next();

				System.out.println("새로운 부서");
				System.out.println(">>>");
				String newDept = in.next();

				System.out.println("새로운 점수");
				System.out.println(">>>");
				int newScore = in.nextInt();
				
				jt.updateEmp(name, newName, newDept, newScore);
				}

			} catch (SQLException e) {
				System.out.println("잘못입력하셨습니다.");
				e.printStackTrace();
			}

			break;
		case 2:
			break;
		default:
			break;

		}

	}

}
