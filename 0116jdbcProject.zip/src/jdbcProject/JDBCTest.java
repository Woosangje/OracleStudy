package jdbcProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCTest {
	// 필드
	// 생성자
	// 메서드
	public void selectEmp() throws SQLException { // Read를 담당하는 메서드

		Connection conn = null; // db연결을 담당하는 타입
		Statement stmt = null; // 정적쿼리를 담당하는 타입
		PreparedStatement pstmt = null; // 동적쿼리를 담당하는 타입
		ResultSet rs = null; // 쿼리 결과 표를 담당하는 타입

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.203:1521:xe", "jdbctest", "jdbctest");
			// 드라이버와 같이 사용될 url, id, pw를 연결 정보 생성

			stmt = conn.createStatement(); // 쿼리문 생성용 준비작업
			rs = stmt.executeQuery("select * from emp order by num asc");
			// 쿼리 실행 후 resultset표에 저장

			System.out.println("사원번호\t 이름\t 부서\t 입사점수");
			System.out.println("--------------------------------------------");
			while (rs.next()) { // rs.next() 다음행이 있으면 true, 없으면 false
				System.out.print(rs.getInt("NUM") + "\t"); // num필드값 int타입으로 출력
				System.out.print(rs.getString("NAME") + "\t"); // name 필드값 String 타입으로
				System.out.print(rs.getString("DEPT") + "\t"); // dept 필드값 String 타입으로
				System.out.println(rs.getDouble("SCORE")); // Score 필드값 Double 타입으로
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally { // 항상실행 블럭
			rs.close(); // resultset 닫기
			stmt.close(); // 쿼리문 닫기
			conn.close(); // 연결 닫기
		} // try문 입력 종료
	} // selectEmp() 메서드 종료

	public void insertEmp1(String name, String dept, double score) throws SQLException {
		Connection conn = null;
		Statement stmt = null;
		int n; // 결과값이 정수로 나옴(1개의 행이 입력되었습니다.)

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.203:1521:xe", "jdbctest", "jdbctest");
			// 드라이버와 같이 사용될 url, id, pw를 연결 정보 생성

			String sql = "insert into emp(num, name, dept, score) " + "values(emp_seq.nextval, '" + name + "','" + dept
					+ "','" + score + "')";
			// values(emp_seq.nextval, 'name', 'dept', 'score')
			stmt = conn.createStatement(); // 쿼리문 객체 준비
			n = stmt.executeUpdate(sql);
			if (n > 0) {
				System.out.println(n + "행 데이터를 추가하였습니다.\n");
				conn.commit();
			}

		} catch (ClassNotFoundException e) { // 클래스가 없을 때 예외처리
			e.printStackTrace(); // 로그 출력
		} finally {
			stmt.close();
			conn.close();

		}

	} // insertEmp1() 정적쿼리문으로 삽입 테스트

	public void insertEmp2(String name, String dept, double score) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int n; // 결과값이 정수로 나옴(1개의 행이 입력되었습니다.)

		try { // 일반 실행문
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.203:1521:xe", "jdbctest", "jdbctest");
			// 드라이버와 같이 사용될 url, id, pw를 연결 정보 생성

			String sql = "insert into emp(num, name, dept, score) " + "values(emp_seq.nextval, ?, ?, ?)";
			// values(emp_seq.nextval, 'name', 'dept', 'score') ?는 인파라미터 형식
			pstmt = conn.prepareStatement(sql); // 동적쿼리문 생성
			pstmt.setString(1, name); // 첫번째 ?에 들어갈 값 삽입
			pstmt.setString(2, dept); // 두번째 ?
			pstmt.setDouble(3, score); // 세번째 ?

			n = pstmt.executeUpdate(); // 쿼리문 실행 후 결과를 int n에 넣는다.
			if (n > 0) {
				System.out.println(n + "행 데이터를 추가하였습니다.\n");
				conn.commit();
			}

		} catch (SQLException e) { // 클래스가 없을 때 예외처리
			System.out.println("쿼리문이 정상적이지 않습니다.");
			conn.rollback(); // 정상문이 아닐때 되돌리는
		} finally {
			pstmt.close();
			conn.close();

		}

	} // insertEmp2() 정적쿼리문으로 삽입 테스트
	public boolean isFindEmp(String name) throws SQLException {
		Connection conn = null; // db연결을 담당하는 타입
		Statement stmt = null; // 정적쿼리를 담당하는 타입
		PreparedStatement pstmt = null; // 동적쿼리를 담당하는 타입
		ResultSet rs = null; // 쿼리 결과 표를 담당하는 타입

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.203:1521:xe", "jdbctest", "jdbctest");
			// 드라이버와 같이 사용될 url, id, pw를 연결 정보 생성

			stmt = conn.createStatement(); // 쿼리문 생성용 준비작업
			rs = stmt.executeQuery("select * from emp order by num asc");
			// 쿼리 실행 후 resultset표에 저장

			System.out.println("사원번호\t 이름\t 부서\t 입사점수");
			System.out.println("--------------------------------------------");
			while (rs.next()) { // rs.next() 다음행이 있으면 true, 없으면 false
				if(rs.getString("NAME").equals(name)) {
				System.out.print(rs.getInt("NUM") + "\t"); // num필드값 int타입으로 출력
				System.out.print(rs.getString("NAME") + "\t"); // name 필드값 String 타입으로
				System.out.print(rs.getString("DEPT") + "\t"); // dept 필드값 String 타입으로
				System.out.println(rs.getDouble("SCORE")); // Score 필드값 Double 타입으로
				return true;
				}
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally { // 항상실행 블럭
			rs.close(); // resultset 닫기
			stmt.close(); // 쿼리문 닫기
			conn.close(); // 연결 닫기
		} // try문 입력 종료
		System.out.println("검색결과가 없습니다.");
		return false;
		
	}
	
	public void updateEmp(String name,String newName, String newDept, double newScore ) throws SQLException {
		//이름 찾은 후 수정
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; // 쿼리 결과 표를 담당하는 타입
		int n; // 결과값이 정수로 나옴(1개의 행이 입력되었습니다.)

		try { // 일반 실행문
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.203:1521:xe", "jdbctest", "jdbctest");
			// 드라이버와 같이 사용될 url, id, pw를 연결 정보 생성

			String sql = "UPDATE EMP (num, name, dept, score) " + "values(emp_seq.nextval, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql); // 동적쿼리문 생성
			pstmt.setString(1, newName); // 첫번째 ?에 들어갈 값 삽입
			pstmt.setString(2, newDept); // 두번째 ?
			pstmt.setDouble(3, newScore); // 세번째 ?
			n = pstmt.executeUpdate(); // 쿼리문 실행 후 결과를 int n에 넣는다.

			if (n > 0) {
				System.out.println(n + "행 데이터를 수정하였습니다.\n");
				conn.commit();
			}
			rs = pstmt.executeQuery("select * from emp where NAME = ?");
			pstmt.setString(1, name); // NAME ?에 들어갈 값 삽입
				System.out.printf(rs.getInt("NUM") + "\t"); // num필드값 int타입으로 출력
				System.out.print(rs.getString("NAME") + "\t"); // name 필드값 String 타입으로
				System.out.print(rs.getString("DEPT") + "\t"); // dept 필드값 String 타입으로
				System.out.println(rs.getDouble("SCORE")); // Score 필드값 Double 타입으로
				
			

		} catch (ClassNotFoundException e) { // 클래스가 없을 때 예외처리
			System.out.println("쿼리문이 정상적이지 않습니다.");
			conn.rollback(); // 정상문이 아닐때 되돌리는
		} catch(SQLException e) {
			
		}finally {
			pstmt.close();
			conn.close();

		}

	} // insertEmp1() 정적쿼리문으로 삽입 테스트

}
