
create table emp(
num number(5) primary key,
name varchar2(16) not null,
dept varchar2(16),
score number(7,2));  --emp 테이블 생성

--테이블 잘못 생성시 삭제
drop table emp;

create sequence emp_seq increment by 1 start with 1 nocache nocycle; --자동번호 생성
drop sequence emp_seq ; -- 자동번호 생성객체 삭제

--실행은 블럭설정 alt + x 
insert into emp(num, name, dept, score) values(emp_seq.nextval, '이름1', '부서1', 75.3);
insert into emp(num, name, dept, score) values(emp_seq.nextval, '이름2', '부서2', 75.3);
insert into emp(num, name, dept, score) values(emp_seq.nextval, '이름3', '부서3', 75.3);
insert into emp(num, name, dept, score) values(emp_seq.nextval, '이름4', '부서4', 75.3);
insert into emp(num, name, dept, score) values(emp_seq.nextval, '이름5', '부서5', 75.3);
insert into emp(num, name, dept, score) values(emp_seq.nextval, '이름6', '부서6', 75.3);

select * from emp;
